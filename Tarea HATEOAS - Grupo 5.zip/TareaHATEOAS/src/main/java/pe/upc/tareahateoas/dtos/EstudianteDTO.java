package pe.upc.tareahateoas.dtos;

import lombok.Data;

@Data
public class EstudianteDTO {
    private Long id;
    private String name;
    private double notaPC1;
    private double notaPC2;
    private double notaExamenFinal;
}
