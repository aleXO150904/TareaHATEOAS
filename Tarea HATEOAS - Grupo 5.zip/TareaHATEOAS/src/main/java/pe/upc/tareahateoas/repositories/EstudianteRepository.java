package pe.upc.tareahateoas.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import pe.upc.tareahateoas.entities.Estudiante;

@Repository
public interface EstudianteRepository extends JpaRepository<Estudiante, Long> {

    @Query("SELECT (e.notaPC1 * 0.20 + e.notaPC2 * 0.20 + e.notaExamenFinal * 0.60) as promedio " +
            "FROM Estudiante e")
    Estudiante obtenerPromedio(double notaPC1, double notaPC2, double notaExamenFinal);
}
