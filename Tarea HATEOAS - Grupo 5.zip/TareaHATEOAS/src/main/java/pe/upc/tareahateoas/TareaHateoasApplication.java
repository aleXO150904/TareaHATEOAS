package pe.upc.tareahateoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TareaHateoasApplication {

    public static void main(String[] args) {
        SpringApplication.run(TareaHateoasApplication.class, args);
    }

}
