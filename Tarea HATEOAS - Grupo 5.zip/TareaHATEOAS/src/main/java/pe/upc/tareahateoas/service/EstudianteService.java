package pe.upc.tareahateoas.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import pe.upc.tareahateoas.entities.Estudiante;
import pe.upc.tareahateoas.repositories.EstudianteRepository;

import java.util.List;

@Service
public class EstudianteService {
    @Autowired
    private EstudianteRepository estudianteRepository;

    public Estudiante registrarEstudiante(Estudiante estudiante){
        return estudianteRepository.save(estudiante);
    }

    public List<Estudiante> listarEstudiantes(){
        return estudianteRepository.findAll();
    }

    public Estudiante getId(Long id){
        return estudianteRepository.findById(id).get();
    }

    public Estudiante actualizarEstudiante(Estudiante estudiante) throws Exception{
        estudianteRepository.findById(estudiante.getId()).
                orElseThrow(()->new Exception("No se encontró estudiante"));
        return estudianteRepository.save(estudiante);
    }

    public Estudiante borrarEstudiante(Long id) throws Exception{
        Estudiante estudiante = estudianteRepository.findById(id).
                orElseThrow(()->new Exception("No se encontró estudiante"));
        estudianteRepository.delete(estudiante);
        return estudiante;
    }

    public Estudiante calcularPromedio(double notaPC1, double notaPC2, double notaExamenFinal){
        return estudianteRepository.obtenerPromedio(notaPC1, notaPC2, notaExamenFinal);
    }

}
