package pe.upc.tareahateoas.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

import javax.persistence.*;

@Entity
@Data
@Table(name = "estudiante")
@AllArgsConstructor
@NoArgsConstructor
public class Estudiante extends RepresentationModel<Estudiante> {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(length = 70, nullable = false)
    private String name;
    @Column(length = 10, nullable = false)
    private double notaPC1;
    @Column(length = 10, nullable = false)
    private double notaPC2;
    @Column(length = 10, nullable = false)
    private double notaExamenFinal;
}
