package pe.upc.tareahateoas.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.web.bind.annotation.*;
import pe.upc.tareahateoas.dtos.EstudianteDTO;
import pe.upc.tareahateoas.entities.Estudiante;
import pe.upc.tareahateoas.service.EstudianteService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class EstudianteController {
    @Autowired
    private EstudianteService estudianteService;

    @GetMapping("/estudiantes")
    public ResponseEntity<List<Estudiante>> listarEstudiantes(){
        List<Estudiante> estudiantes = estudianteService.listarEstudiantes();
        if(estudiantes.isEmpty()){
            return ResponseEntity.noContent().build();
        }

        for (Estudiante estudiante:estudiantes){
            estudiante.add(linkTo(methodOn(EstudianteController.class).listarEstudiante(estudiante.getId())).withSelfRel());
            estudiante.add(linkTo(methodOn(EstudianteController.class).listarEstudiantes()).withRel(IanaLinkRelations.COLLECTION));
        }

        CollectionModel<Estudiante> modelo = CollectionModel.of(estudiantes);
        modelo.add(linkTo(methodOn(EstudianteController.class).listarEstudiantes()).withSelfRel());

        return new ResponseEntity<>(estudiantes, HttpStatus.OK);
    }

    @GetMapping("/estudiante/{id}")
    public ResponseEntity<Estudiante> listarEstudiante(@PathVariable Long id){
        try{
            Estudiante estudiante = estudianteService.getId(id);

            estudiante.add(linkTo(methodOn(EstudianteController.class).listarEstudiante(estudiante.getId())).withSelfRel());
            estudiante.add(linkTo(methodOn(EstudianteController.class).listarEstudiantes()).withRel(IanaLinkRelations.COLLECTION));

            return new ResponseEntity<>(estudiante,HttpStatus.OK);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/estudiante")
    public ResponseEntity<Estudiante> registrarEstudiante(@RequestBody Estudiante estudiante){
        Estudiante estudiante1 = estudianteService.registrarEstudiante(estudiante);

        estudiante1.add(linkTo(methodOn(EstudianteController.class).listarEstudiante(estudiante1.getId())).withSelfRel());
        estudiante1.add(linkTo(methodOn(EstudianteController.class).listarEstudiantes()).withRel(IanaLinkRelations.COLLECTION));

        return ResponseEntity.created(linkTo(methodOn(EstudianteController.class).listarEstudiante(estudiante1.getId())).toUri()).body(estudiante1);
    }

    @PutMapping("/estudiante")
    public ResponseEntity<Estudiante> editarEstudiante(@RequestBody Estudiante estudiante){
        Estudiante estudiante1 = estudianteService.registrarEstudiante(estudiante);

        estudiante1.add(linkTo(methodOn(EstudianteController.class).listarEstudiante(estudiante1.getId())).withSelfRel());
        estudiante1.add(linkTo(methodOn(EstudianteController.class).listarEstudiantes()).withRel(IanaLinkRelations.COLLECTION));

        return new ResponseEntity<>(estudiante1, HttpStatus.OK);
    }

    @DeleteMapping("/estudiante/{id}")
    public ResponseEntity<?> borrarEstudiante(@PathVariable Long id){
        try {
            estudianteService.borrarEstudiante(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("estudiantes/{id}/promedio")
    public ResponseEntity<Estudiante> calcularPromedio(@RequestBody double notaPC1, @RequestBody double notaPC2, @RequestBody double notaExamenFinal){
        Estudiante estudiante = estudianteService.calcularPromedio(notaPC1, notaPC2, notaExamenFinal);

        estudiante.add(linkTo(methodOn(EstudianteController.class).listarEstudiante(estudiante.getId())).withSelfRel());
        estudiante.add(linkTo(methodOn(EstudianteController.class).calcularPromedio(estudiante.getNotaPC1(), estudiante.getNotaPC2(), estudiante.getNotaExamenFinal())).withRel("promedios"));
        estudiante.add(linkTo(methodOn(EstudianteController.class).listarEstudiantes()).withRel(IanaLinkRelations.COLLECTION));

        return new ResponseEntity<>(estudiante, HttpStatus.OK);

    }



    private Estudiante convertToEntity(EstudianteDTO estudianteDTO){
        ModelMapper modelMapper = new ModelMapper();
        return modelMapper.map(estudianteDTO, Estudiante.class);
    }

    private EstudianteDTO convertToDTO(Estudiante estudiante){
        ModelMapper modelMapper = new ModelMapper();
        return modelMapper.map(estudiante, EstudianteDTO.class);
    }

    private List<EstudianteDTO> convertToListDTO(List<Estudiante> list){
        return list.stream().map(this::convertToDTO).collect(Collectors.toList());
    }
}
